#ifndef _yy_defines_h_
#define _yy_defines_h_

#define N_S_D 257
#define S_D 258
#define MPY 259
#define PLUS 260
#define L_BR 261
#define R_BR 262
#define COMM 263
#define NUMBER 264
#define LINE_END 265

#endif /* _yy_defines_h_ */
