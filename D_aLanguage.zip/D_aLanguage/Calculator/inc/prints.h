#ifndef PRINTS_H
#define PRINTS_H

void debug_print(const char* to_print);
#endif //PRINTS_H